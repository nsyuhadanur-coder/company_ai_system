import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Replace any occurrence of the unicode replacement character
content = content.replace('\ufffd', '')

with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
