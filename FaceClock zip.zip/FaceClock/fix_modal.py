import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Change display:flex to display:none
content = content.replace(
    'style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);z-index:999;display:flex;align-items:center;justify-content:center;"',
    'style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);z-index:999;display:none;align-items:center;justify-content:center;"'
)

with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
