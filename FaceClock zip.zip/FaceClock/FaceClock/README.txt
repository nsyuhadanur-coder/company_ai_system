FACECLOCK - Sistem Kehadiran Muka / Face Attendance System
==========================================================

ISI / CONTENTS
  FaceClock.html               Sistem penuh (10 MB). Berfungsi tanpa internet.
                               The full system. Works offline.
  start-windows.bat            Buka melalui localhost (Windows, perlu Python)
  start-mac-linux.sh           Buka melalui localhost (Mac/Linux, perlu Python 3)
  source/FaceClock-source.html Kod boleh dibaca (perlu internet). Readable source.

CARA GUNA / HOW TO USE
  1. Salin folder ini ke komputer di pintu masuk.
  2. Klik dua kali FaceClock.html (guna Chrome atau Edge).
     Tekan Allow apabila browser minta kebenaran kamera.
  3. Tab "Staff": isi nama, ID, jabatan, tekan "Capture face and save".
  4. Tab "Clock in / out": pilih mod
        Auto      = imbasan pertama hari itu clock in, imbasan seterusnya
                    (selepas 1 minit) clock out
        Clock in  = setiap imbasan direkod clock in
        Clock out = setiap imbasan direkod clock out
  5. Tab "Attendance" (untuk HR): pilih tarikh, lihat status Hadir/Lewat/Tidak
     hadir, tekan "Export CSV" (harian) atau "Backup all scans" (semua rekod).

JIKA KAMERA DISEKAT / IF THE CAMERA IS BLOCKED
  Jalankan start-windows.bat (atau start-mac-linux.sh). Ia membuka
  http://localhost:8000/FaceClock.html di mana kamera lebih dipercayai.
  PENTING: data disimpan berasingan bagi setiap cara buka (klik dua kali
  lawan localhost). Pilih satu cara dan kekalkan.

PENTING / IMPORTANT
  * Data disimpan dalam browser komputer ini sahaja. Jika data browsing
    dikosongkan, semua rekod dan pendaftaran muka hilang. Eksport CSV
    (Backup all scans) secara berkala.
  * Guna satu komputer dan satu browser sahaja untuk pintu masuk.
  * Waktu mula kerja: cari  const START=9*60,GRACE=15;  dalam fail HTML
    (09:00, lewat selepas 09:15). Ubah dengan Notepad jika perlu.
  * Templat muka ialah data biometrik peribadi. Dapatkan persetujuan bertulis
    staf dan hadkan akses kepada HR (PDPA Malaysia).
  * Tiada perlindungan terhadap gambar/skrin telefon (tiada liveness check).
