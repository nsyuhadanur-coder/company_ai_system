import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Add EL tab to nav
if 'data-t="el"' not in content:
    content = content.replace(
        '<button data-t="att">Attendance</button>',
        '<button data-t="att">Attendance</button>\n  <button data-t="el">EL Portal</button>'
    )
    content = content.replace("['clock','staff','att'].forEach", "['clock','staff','att','el'].forEach")

# 2. Re-add EL Section (Without Time and Without Approval)
el_section = """
<section id="p-el" hidden>
 <div class="split">
  <div>
   <h2>Apply for Early Leave (EL)</h2>
   <div class="card">
    <label style="display:block;margin-bottom:5px">Select Staff:</label>
    <select id="elStaffSel" class="txt" style="width:100%;margin-bottom:15px"></select>
    
    <label style="display:block;margin-bottom:5px">EL Reason:</label>
    <select id="elReasonForm" class="txt" style="width:100%;margin-bottom:15px">
     <option value="Family Matters">Family Matters</option>
     <option value="Medical Checkup">Medical Checkup</option>
     <option value="Others">Others</option>
    </select>
    
    <input type="text" id="elOtherForm" class="txt" placeholder="Please specify your reason..." hidden style="width:100%;margin-bottom:15px">
    
    <button class="btn" id="elSubmitBtn" style="width:100%">Submit EL</button>
    <p id="elMsg" class="mute" style="margin-top:10px"></p>
   </div>
  </div>
  <div style="flex:2">
   <h2>EL Records</h2>
   <div class="card" style="padding:0;overflow-x:auto">
    <table class="tbl">
     <thead><tr><th>Date</th><th>Staff</th><th>Reason/Remarks</th><th>Status</th></tr></thead>
     <tbody id="elRows"></tbody>
    </table>
   </div>
  </div>
 </div>
</section>
"""

# Replace any existing modal or p-el
start_modal = content.find('<div id="elModal"')
if start_modal != -1:
    end_modal = content.find('</main>', start_modal)
    content = content[:start_modal] + el_section + content[end_modal:]

# 3. clockIn logic
start_clock = content.find("async function clockIn(m){")
end_clock = content.find("async function loop(){", start_clock)

new_clockIn = """async function clockIn(m){
 if(!db){say('Storage unavailable in this browser.','bad');return}
 const now=Date.now(),d=new Date(now),today=dstr(d);
 const mine=logs.filter(l=>l.staffId===m.id&&l.date===today).sort((a,b)=>a.ts-b.ts),lg=mine[mine.length-1];
 let type;
 if(now-(cool[m.id]||0)<60000){ring('ok');say(`${m.name}: already clocked ${lg?lg.type:'in'} at ${lg?tstr(lg.ts):tstr(now)}. Scan again in a minute to clock out.`,'ok');return}
 type=!lg||lg.type==='out'?'in':'out';
 if(type==='in'&&d.getHours()<9){ring('unk');say(`${m.name}: Too early to clock in. Starts at 9:00 AM.`,'warn');return}
 const isLate=type==='in'&&(d.getHours()>9||(d.getHours()===9&&d.getMinutes()>0));
 let ot=0, el=false, elReason='', elRemarks='';
 if(type==='out'){
  const otStart=new Date(d.getFullYear(),d.getMonth(),d.getDate(),18,0,0,0).getTime();
  ot=now>otStart?now-otStart:0;
  if(now<otStart){
   const appliedEl = els.find(e => e.staffId === m.id && e.date === today);
   if(appliedEl){
     el = true;
     elReason = appliedEl.reason;
     elRemarks = appliedEl.remarks;
   } else {
     busy=false; last={id:null,n:0}; ring('unk'); say('Early Clock-Out Blocked. Please apply for EL in EL Portal first.', 'warn'); return;
   }
  }
 }
 busy=true;
 try{
  await db.collection('attendance').add({staffId:m.id,name:m.name,dept:m.dept||'',type,ts:now,date:today,late:isLate,ot,el,elReason,elRemarks});
  cool[m.id]=now;ring('ok');say(`${m.name}: CLOCKED ${type.toUpperCase()} at ${tstr(now)}${isLate?' (LATE)':''}`,type==='out'?'out':isLate?'warn':'ok');
  if(m.dist<0.35&&m.matchVec&&m.currVec){
   const updatedVec=Array.from(m.matchVec).map((val,i)=>val*0.9+m.currVec[i]*0.1);
   if(m.matchIdx>=0&&m.vecs){
    const newVecs=[...m.vecs];newVecs[m.matchIdx]=updatedVec;
    db.collection('staff').doc(m.id).update({vecs:newVecs}).catch(e=>{});
   }else{
    db.collection('staff').doc(m.id).update({vec:updatedVec}).catch(e=>{});
   }
  }
 }
 catch(e){say('Could not save attendance: '+(e.message||e.code),'bad')}
 setTimeout(()=>{busy=false;last={id:null,n:0}},2500)}
"""
content = content[:start_clock] + new_clockIn + content[end_clock:]


# 4. Inject EL variables and listeners
if 'els=[],' not in content:
    content = content.replace('staff=[],logs=[],', 'staff=[],logs=[],els=[],')

snap_str = "db.collection('attendance')"
if "db.collection('el_requests')" not in content:
    content = content.replace(snap_str, "db.collection('el_requests').orderBy('applied_at','desc').limit(1000).onSnapshot(s=>{els=s.docs.map(d=>({id:d.id,...d.data()}));render()},()=>{});\n  " + snap_str)


# 5. Add rendering for EL Portal
start_render = content.find("function render(){")
end_render = content.find("\n if(tab!=='att')return;", start_render)

render_body = """function render(){
 $('#recent').innerHTML=logs.filter(l=>l.date===dstr(new Date())).slice(0,8).map(l=>`<li><span>${esc(l.name)}</span><span class="mute">Clock ${l.type} ${tstr(l.ts)}</span></li>`).join('')||'<li class="mute">No scans yet today.</li>';
 $('#staffList').innerHTML=staff.map(s=>`<li><span>${esc(s.name)} <span class="mute">${esc(s.id)} ${esc(s.dept)}</span></span><button class="btn ghost sm" data-id="${esc(s.id)}">Remove</button></li>`).join('')||'<li class="mute">Nobody enrolled yet.</li>';
 
 if($('#elStaffSel')){
   $('#elStaffSel').innerHTML = '<option value="">-- Select Employee --</option>' + staff.map(s=>`<option value="${esc(s.id)}">${esc(s.name)}</option>`).join('');
   $('#elReasonForm').onchange=e=>$('#elOtherForm').hidden=(e.target.value!=='Others');
   
   $('#elRows').innerHTML = els.map(e => {
     let stat = '<span class="pill p-in">APPLIED</span>';
     let rText = e.reason + (e.remarks ? ` - ${e.remarks}` : '');
     return `<tr><td>${esc(e.date)}</td><td>${esc(e.staffName)}</td><td>${esc(rText)}</td><td>${stat}</td></tr>`;
   }).join('') || '<tr><td colspan="4" class="mute">No EL requests found.</td></tr>';
   
   $('#elSubmitBtn').onclick = async () => {
     const sid = $('#elStaffSel').value, reason = $('#elReasonForm').value;
     const remarks = reason==='Others'?$('#elOtherForm').value.trim():'';
     const m = t => $('#elMsg').textContent=t;
     if(!sid || !reason) return m('Please select staff and reason.');
     if(reason==='Others' && !remarks) return m('Please specify the reason.');
     const s = staff.find(x=>x.id===sid);
     if(!db) return m('Storage unavailable');
     
     $('#elSubmitBtn').disabled=true;
     try {
       await db.collection('el_requests').add({
         staffId: s.id, staffName: s.name, dept: s.dept||'', date: dstr(new Date()), reason, remarks, applied_at: Date.now()
       });
       m('EL applied successfully! You can now clock out.');
       $('#elOtherForm').value='';
     } catch(e) {
       m('Error: ' + e.message);
     }
     $('#elSubmitBtn').disabled=false;
   };
 }
"""

content = content[:start_render] + render_body + content[end_render:]

with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
