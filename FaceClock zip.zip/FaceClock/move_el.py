import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Remove EL Portal tab
content = content.replace('\n  <button data-t="el">EL Portal</button>', '')
content = content.replace("['clock','staff','att','el'].forEach", "['clock','staff','att'].forEach")

# 2. Extract and delete p-el
start_el = content.find('<section id="p-el" hidden>')
if start_el != -1:
    end_el = content.find('</section>', start_el)
    content = content[:start_el] + content[end_el + 10:]

# 3. Add EL Form to p-clock
el_form = """
   <div class="card" style="margin-bottom:20px; background: rgba(30,41,59,0.5);">
    <h3 style="margin-top:0">Early Leave (EL)</h3>
    <label style="display:block;margin-bottom:5px;font-size:0.9em">Select Staff:</label>
    <select id="elStaffSel" class="txt" style="width:100%;margin-bottom:10px"></select>
    
    <label style="display:block;margin-bottom:5px;font-size:0.9em">EL Reason:</label>
    <select id="elReasonForm" class="txt" style="width:100%;margin-bottom:10px">
     <option value="Family Matters">Family Matters</option>
     <option value="Medical Checkup">Medical Checkup</option>
     <option value="Others">Others</option>
    </select>
    
    <input type="text" id="elOtherForm" class="txt" placeholder="Please specify your reason..." hidden style="width:100%;margin-bottom:10px">
    
    <button class="btn" id="elSubmitBtn" style="width:100%">Submit EL</button>
    <p id="elMsg" class="mute" style="margin-top:10px;font-size:0.85em"></p>
   </div>
   <h2>Recent Scans</h2>"""

content = content.replace('<h2>Recent Scans</h2>', el_form)

# 4. Remove EL Rows rendering from JS as we deleted the table
start_rows = content.find("$('#elRows').innerHTML = els.map(")
if start_rows != -1:
    end_rows = content.find("</tr>';", start_rows)
    content = content[:start_rows] + content[end_rows + 8:]

with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
