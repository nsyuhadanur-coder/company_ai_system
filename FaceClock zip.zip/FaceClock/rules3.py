with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

# REPLACE THE TABLE HEADERS
old_th = "<th>Staff ID</th><th>Name</th><th>Department</th><th>Clock-in</th><th>Clock-out</th><th>OT Duration</th><th>Status</th>"
new_th = "<th>Staff ID</th><th>Name</th><th>Department</th><th>Clock-in</th><th>Clock-out</th><th>Duration</th><th>EL/Reason</th><th>Status</th>"
content = content.replace(old_th, new_th)

# UPDATE RENDER TO INCLUDE NEW COLUMNS
start = content.find(" $('#rows').innerHTML=rows.map(r=>`<tr><td>${esc(r.id)}")
if start != -1:
    end = content.find("</script>", start)
    # the entire line
    end_line = content.find("\\n", start)
    
    old_line = content[start:end_line]
    
    new_line = " $('#rows').innerHTML=rows.map(r=>{ let dur=''; if(r.out&&r.el){let elD=Math.max(0,(new Date(new Date(r.out).setHours(18,0,0,0))-r.out)/36e5).toFixed(1); dur=`${elD} hrs EL`;}else if(r.otHrs) dur=`${r.otHrs} hrs OT`; return `<tr><td>${esc(r.id)}</td><td>${esc(r.name)}</td><td>${esc(r.dept)}</td><td>${r.first?tstr(r.first):'-'}</td><td>${r.out?tstr(r.out):r.onsite?'<span class=\"pill p-in\">On site</span>':'-'}</td><td>${dur||'-'}</td><td>${esc(r.elReason||'')}</td><td>${r.statusHTML}</td></tr>`}).join('')||'<tr><td colspan=\"8\" class=\"mute\">Enrol staff to start tracking attendance.</td></tr>'}"
    
    content = content[:start] + new_line + content[end_line:]

with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
