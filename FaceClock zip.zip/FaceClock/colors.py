import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Add CSS root variable and class for EL
if '--el:' not in content:
    content = content.replace(':root{', ':root{--el:#a855f7;')
if '.p-el' not in content:
    content = content.replace('.p-in{color:var(--accent)}', '.p-in{color:var(--accent)}.p-el{color:var(--el);border-color:var(--el)}')

# 2. Update summary logic for EL pill class
content = content.replace('<span class="pill p-warn" title="\'', '<span class="pill p-el" title="\'')

with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
