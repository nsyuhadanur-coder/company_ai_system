import re
with open('FaceClock.html', encoding='utf-8') as f:
    for i, line in enumerate(f):
        if 'function render()' in line or 'function summary(' in line or '$(\'#rows\').innerHTML=' in line:
            print(f"{i}: {line.strip()}")
