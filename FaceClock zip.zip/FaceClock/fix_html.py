import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

el_section = """
<section id="p-el" hidden>
 <div class="split">
  <div>
   <h2>Apply for Early Leave (EL)</h2>
   <div class="card">
    <label style="display:block;margin-bottom:5px">Select Staff:</label>
    <select id="elStaffSel" class="txt" style="width:100%;margin-bottom:15px"></select>
    
    <label style="display:block;margin-bottom:5px">Expected Clock-Out Time:</label>
    <input type="time" id="elTime" class="txt" style="width:100%;margin-bottom:15px">
    
    <label style="display:block;margin-bottom:5px">EL Reason:</label>
    <select id="elReasonForm" class="txt" style="width:100%;margin-bottom:15px">
     <option value="Family Matters">Family Matters</option>
     <option value="Medical Checkup">Medical Checkup</option>
     <option value="Others">Others</option>
    </select>
    
    <input type="text" id="elOtherForm" class="txt" placeholder="Please specify your reason..." hidden style="width:100%;margin-bottom:15px">
    
    <button class="btn" id="elSubmitBtn" style="width:100%">Submit EL Application</button>
    <p id="elMsg" class="mute" style="margin-top:10px"></p>
   </div>
  </div>
  <div style="flex:2">
   <h2>HR EL Management</h2>
   <div class="card" style="padding:0;overflow-x:auto">
    <table class="tbl">
     <thead><tr><th>Date</th><th>Staff</th><th>Requested Time</th><th>Reason/Remarks</th><th>Status</th><th>Action</th></tr></thead>
     <tbody id="elRows"></tbody>
    </table>
   </div>
  </div>
 </div>
</section>
"""

content = content.replace("</main>", el_section + "</main>")

with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
