import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

start = content.find(" $('#rows').innerHTML=rows.map(r=>{ let dur='';")
end = content.find("dl.save({filename:'all-scans-'+dstr(new Date())+'.csv',data:csv})};")

if start != -1 and end != -1:
    replacement = """ $('#rows').innerHTML=rows.map(r=>{ let dur=''; if(r.out&&r.el){let elD=Math.max(0,(new Date(new Date(r.out).setHours(18,0,0,0))-r.out)/36e5).toFixed(1); dur=`${elD} hrs EL`;}else if(r.otHrs) dur=`${r.otHrs} hrs OT`; return `<tr><td>${esc(r.id)}</td><td>${esc(r.name)}</td><td>${esc(r.dept)}</td><td>${r.first?tstr(r.first):'-'}</td><td>${r.out?tstr(r.out):r.onsite?'<span class="pill p-in">On site</span>':'-'}</td><td>${dur||'-'}</td><td>${esc(r.elReason||'')}</td><td>${r.statusHTML}</td></tr>`}).join('')||'<tr><td colspan="8" class="mute">Enrol staff to start tracking attendance.</td></tr>'}
$('#all').onclick=()=>{const q=v=>`"${String(v??'').replace(/"/g,'""')}"`;const csv=['Date,Time,Staff ID,Name,Department,Type,OT (ms)',...[...logs].sort((a,b)=>a.ts-b.ts).map(l=>[l.date,tstr(l.ts),l.staffId,l.name,l.dept,l.type,l.ot||''].map(q).join(','))].join('\\n');dl.save({filename:'all-scans-'+dstr(new Date())+'.csv',data:csv})};"""

    end = end + len("dl.save({filename:'all-scans-'+dstr(new Date())+'.csv',data:csv})};")
    content = content[:start] + replacement + content[end:]
    
with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
