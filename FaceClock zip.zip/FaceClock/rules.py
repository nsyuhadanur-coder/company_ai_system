import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

# ADD MODAL TO HTML
modal_html = """
<div id="elModal" hidden style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);z-index:999;display:flex;align-items:center;justify-content:center;">
 <div class="card" style="width:340px;max-width:90%">
  <h3>Early Clock-Out</h3>
  <p class="mute">You are clocking out before 6:00 PM.</p>
  <label>Select Reason:</label>
  <select id="elReason" class="txt" style="width:100%;margin-bottom:10px">
   <option value="">(No Reason - Early Clock Out)</option>
   <option value="Family Matters">Family Matters</option>
   <option value="Medical Checkup">Medical Checkup</option>
   <option value="Others">Others</option>
  </select>
  <input type="text" id="elOther" class="txt" placeholder="Please specify..." hidden style="width:100%;margin-bottom:10px">
  <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:10px">
   <button class="btn ghost" id="elCancel">Cancel</button>
   <button class="btn" id="elConfirm">Confirm</button>
  </div>
 </div>
</div>
</main>"""

content = content.replace("</main>", modal_html)

# REPLACE CLOCK IN
new_clockIn = """async function clockIn(m){
 if(!db){say('Storage unavailable in this browser.','bad');return}
 const now=Date.now(),d=new Date(now),today=dstr(d);
 const mine=logs.filter(l=>l.staffId===m.id&&l.date===today).sort((a,b)=>a.ts-b.ts),lg=mine[mine.length-1];
 let type;
 if(now-(cool[m.id]||0)<60000){ring('ok');say(`${m.name}: already clocked ${lg?lg.type:'in'} at ${lg?tstr(lg.ts):tstr(now)}. Scan again in a minute to clock out.`,'ok');return}
 type=!lg||lg.type==='out'?'in':'out';
 if(type==='in'&&d.getHours()<9){ring('unk');say(`${m.name}: Too early to clock in. Starts at 9:00 AM.`,'warn');return}
 const isLate=type==='in'&&(d.getHours()>9||(d.getHours()===9&&d.getMinutes()>0));
 let ot=0, el=false, elReason='';
 if(type==='out'){
  const otStart=new Date(d.getFullYear(),d.getMonth(),d.getDate(),18,0,0,0).getTime();
  ot=now>otStart?now-otStart:0;
  if(now<otStart){
   busy=true; $('#elModal').style.display='flex'; $('#elModal').hidden=false; $('#elReason').value=''; $('#elOther').hidden=true; $('#elOther').value='';
   $('#elReason').onchange=e=>$('#elOther').hidden=(e.target.value!=='Others');
   let res = await new Promise(r=>{
    $('#elCancel').onclick=()=>{r(null)};
    $('#elConfirm').onclick=()=>{let v=$('#elReason').value; r(v==='Others'?$('#elOther').value.trim():v)};
   });
   $('#elModal').hidden=true; $('#elModal').style.display='none';
   if(res===null){busy=false; ring('unk'); say('Clock-out cancelled.','warn'); return;}
   el=true; elReason=res;
  }
 }
 busy=true;
 try{
  await db.collection('attendance').add({staffId:m.id,name:m.name,dept:m.dept||'',type,ts:now,date:today,late:isLate,ot,el,elReason});
  cool[m.id]=now;ring('ok');say(`${m.name}: CLOCKED ${type.toUpperCase()} at ${tstr(now)}${isLate?' (LATE)':''}`,type==='out'?'out':isLate?'warn':'ok');
  if(m.dist<0.35&&m.matchVec&&m.currVec){
   const updatedVec=Array.from(m.matchVec).map((val,i)=>val*0.9+m.currVec[i]*0.1);
   if(m.matchIdx>=0&&m.vecs){
    const newVecs=[...m.vecs];newVecs[m.matchIdx]=updatedVec;
    db.collection('staff').doc(m.id).update({vecs:newVecs}).catch(e=>{});
   }else{
    db.collection('staff').doc(m.id).update({vec:updatedVec}).catch(e=>{});
   }
  }
 }
 catch(e){say('Could not save attendance: '+(e.message||e.code),'bad')}
 setTimeout(()=>{busy=false;last={id:null,n:0}},2500)}"""

content = re.sub(r"async function clockIn\(m\)\{.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n\}", new_clockIn, content, flags=re.DOTALL)


# REPLACE SUMMARY
new_summary = """function summary(day){
 const map=new Map();staff.forEach(s=>map.set(s.id,{id:s.id,name:s.name,dept:s.dept,ev:[]}));
 logs.filter(l=>l.date===day).forEach(l=>{if(!map.has(l.staffId))map.set(l.staffId,{id:l.staffId,name:l.name,dept:l.dept,ev:[]});map.get(l.staffId).ev.push(l)});
 return [...map.values()].map(p=>{p.ev.sort((a,b)=>a.ts-b.ts);const ins=p.ev.filter(e=>e.type==='in'),lg=p.ev[p.ev.length-1];
  p.first=ins[0]?.ts;p.out=lg&&lg.type==='out'?lg.ts:null;p.hrs=p.first&&p.out?((p.out-p.first)/36e5).toFixed(1):'';
  const d=p.first&&new Date(p.first),mins=d?d.getHours()*60+d.getMinutes():0;
  p.absent=!p.first; p.late=p.first&&(ins[0]&&ins[0].late!==undefined?ins[0].late:mins>540);
  p.onsite=p.first&&!p.out;
  p.otHrs=lg&&lg.type==='out'&&lg.ot?(lg.ot/36e5).toFixed(1):'';
  p.elReason=lg&&lg.type==='out'&&lg.el?lg.elReason:'';
  
  if (p.absent) p.statusHTML = '<span class="pill p-bad">ABSENT</span>';
  else {
    p.statusHTML = p.late ? '<span class="pill p-warn">LATE</span>' : '<span class="pill p-ok">ON TIME</span>';
    if (p.out) {
      if (lg.el) {
        if (lg.elReason) p.statusHTML += ' <span class="pill p-warn">EL ('+esc(lg.elReason)+')</span>';
        else p.statusHTML += ' <span class="pill p-bad">EARLY CLOCK-OUT</span>';
      } else {
        p.statusHTML += (lg.ot > 0) ? ' <span class="pill p-in">OVERTIME</span>' : ' <span class="pill p-ok">NORMAL CLOCK OUT</span>';
      }
    }
  }
  p.statusText = p.statusHTML.replace(/<[^>]+>/g, '').trim().replace(/\\s{2,}/g, ', ');

  return p}).sort((a,b)=>a.name.localeCompare(b.name))}"""

content = re.sub(r"function summary\(day\)\{.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\}", new_summary, content, flags=re.DOTALL)


with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
