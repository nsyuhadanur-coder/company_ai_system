import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix mock DB
old_doc = "doc:id=>({set(v){const o=rd();o[id]=v;wr(o);return Promise.resolve()},delete(){const o=rd();delete o[id];wr(o);return Promise.resolve()}})"
new_doc = "doc:id=>({set(v,opts){const o=rd();o[id]=opts&&opts.merge?{...(o[id]||{}),...v}:v;wr(o);return Promise.resolve()},update(v){const o=rd();if(o[id])o[id]={...o[id],...v};wr(o);return Promise.resolve()},delete(){const o=rd();delete o[id];wr(o);return Promise.resolve()}})"
content = content.replace(old_doc, new_doc)

with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
