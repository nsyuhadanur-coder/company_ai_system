import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Add EL Portal Tab
content = content.replace(
    '<button data-t="att">Attendance</button>',
    '<button data-t="att">Attendance</button>\n  <button data-t="el">EL Portal</button>'
)

# 2. Add EL Portal Section
el_section = """</section>
<section id="p-el" hidden>
 <div class="split">
  <div>
   <h2>Apply for Early Leave (EL)</h2>
   <div class="card">
    <label style="display:block;margin-bottom:5px">Select Staff:</label>
    <select id="elStaffSel" class="txt" style="width:100%;margin-bottom:15px"></select>
    
    <label style="display:block;margin-bottom:5px">Expected Clock-Out Time:</label>
    <input type="time" id="elTime" class="txt" style="width:100%;margin-bottom:15px">
    
    <label style="display:block;margin-bottom:5px">EL Reason:</label>
    <select id="elReasonForm" class="txt" style="width:100%;margin-bottom:15px">
     <option value="Family Matters">Family Matters</option>
     <option value="Medical Checkup">Medical Checkup</option>
     <option value="Others">Others</option>
    </select>
    
    <input type="text" id="elOtherForm" class="txt" placeholder="Please specify your reason..." hidden style="width:100%;margin-bottom:15px">
    
    <button class="btn" id="elSubmitBtn" style="width:100%">Submit EL Application</button>
    <p id="elMsg" class="mute" style="margin-top:10px"></p>
   </div>
  </div>
  <div style="flex:2">
   <h2>HR EL Management</h2>
   <div class="card" style="padding:0;overflow-x:auto">
    <table class="tbl">
     <thead><tr><th>Date</th><th>Staff</th><th>Requested Time</th><th>Reason/Remarks</th><th>Status</th><th>Action</th></tr></thead>
     <tbody id="elRows"></tbody>
    </table>
   </div>
  </div>
 </div>
</section>"""
content = content.replace("</section>\n</main>", el_section + "\n</main>")

# 3. Remove elModal (which was added in previous turns)
start_modal = content.find('<div id="elModal"')
if start_modal != -1:
    end_modal = content.find('</main>', start_modal)
    content = content[:start_modal] + content[end_modal:]

# 4. Modify logic
# - Add `els=[]` to state
content = content.replace('staff=[],logs=[],', 'staff=[],logs=[],els=[],')
content = content.replace("['clock','staff','att'].forEach", "['clock','staff','att','el'].forEach")

# - Listen to `el_requests`
start_snap = content.find("db.collection('attendance')")
el_snap = "db.collection('el_requests').orderBy('applied_at','desc').limit(1000).onSnapshot(s=>{els=s.docs.map(d=>({id:d.id,...d.data()}));render()},()=>{});\n  "
content = content[:start_snap] + el_snap + content[start_snap:]

# - Implement clockIn logic replacement
start_clockIn = content.find("async function clockIn(m){")
end_clockIn = content.find("async function loop(){", start_clockIn)

new_clockIn = """async function clockIn(m){
 if(!db){say('Storage unavailable in this browser.','bad');return}
 const now=Date.now(),d=new Date(now),today=dstr(d);
 const mine=logs.filter(l=>l.staffId===m.id&&l.date===today).sort((a,b)=>a.ts-b.ts),lg=mine[mine.length-1];
 let type;
 if(now-(cool[m.id]||0)<60000){ring('ok');say(`${m.name}: already clocked ${lg?lg.type:'in'} at ${lg?tstr(lg.ts):tstr(now)}. Scan again in a minute to clock out.`,'ok');return}
 type=!lg||lg.type==='out'?'in':'out';
 if(type==='in'&&d.getHours()<9){ring('unk');say(`${m.name}: Too early to clock in. Starts at 9:00 AM.`,'warn');return}
 const isLate=type==='in'&&(d.getHours()>9||(d.getHours()===9&&d.getMinutes()>0));
 let ot=0, el=false, elReason='', elRemarks='', elId='';
 if(type==='out'){
  const otStart=new Date(d.getFullYear(),d.getMonth(),d.getDate(),18,0,0,0).getTime();
  ot=now>otStart?now-otStart:0;
  if(now<otStart){
   const approvedEl = els.find(e => e.staffId === m.id && e.date === today && e.status === 'APPROVED');
   if(approvedEl){
     el = true;
     elId = approvedEl.id;
     elReason = approvedEl.reason;
     elRemarks = approvedEl.remarks;
   } else {
     busy=false; last={id:null,n:0}; ring('unk'); say('Early Clock-Out Not Allowed. No approved EL.', 'warn'); return;
   }
  }
 }
 busy=true;
 try{
  await db.collection('attendance').add({staffId:m.id,name:m.name,dept:m.dept||'',type,ts:now,date:today,late:isLate,ot,el,elId,elReason,elRemarks});
  cool[m.id]=now;ring('ok');say(`${m.name}: CLOCKED ${type.toUpperCase()} at ${tstr(now)}${isLate?' (LATE)':''}`,type==='out'?'out':isLate?'warn':'ok');
  if(m.dist<0.35&&m.matchVec&&m.currVec){
   const updatedVec=Array.from(m.matchVec).map((val,i)=>val*0.9+m.currVec[i]*0.1);
   if(m.matchIdx>=0&&m.vecs){
    const newVecs=[...m.vecs];newVecs[m.matchIdx]=updatedVec;
    db.collection('staff').doc(m.id).update({vecs:newVecs}).catch(e=>{});
   }else{
    db.collection('staff').doc(m.id).update({vec:updatedVec}).catch(e=>{});
   }
  }
 }
 catch(e){say('Could not save attendance: '+(e.message||e.code),'bad')}
 setTimeout(()=>{busy=false;last={id:null,n:0}},2500)}
"""
content = content[:start_clockIn] + new_clockIn + content[end_clockIn:]

# 5. Add rendering and event listeners for EL
render_injection = """
 $('#elStaffSel').innerHTML = '<option value="">-- Select Employee --</option>' + staff.map(s=>`<option value="${esc(s.id)}">${esc(s.name)}</option>`).join('');
 $('#elReasonForm').onchange=e=>$('#elOtherForm').hidden=(e.target.value!=='Others');
 
 window.updateEL = async (id, status) => {
   if(!db)return;
   await db.collection('el_requests').doc(id).set({status, [status==='APPROVED'?'approved_at':'rejected_at']:Date.now()}, {merge:true});
 };
 
 $('#elRows').innerHTML = els.map(e => {
   let act = e.status==='PENDING' ? `<button class="btn sm" onclick="updateEL('${e.id}','APPROVED')">Approve</button> <button class="btn ghost sm" onclick="updateEL('${e.id}','REJECTED')">Reject</button>` : '';
   let stat = e.status==='APPROVED'?'<span class="pill p-ok">APPROVED</span>':e.status==='REJECTED'?'<span class="pill p-bad">REJECTED</span>':'<span class="pill p-warn">PENDING</span>';
   let rText = e.reason + (e.remarks ? ` - ${e.remarks}` : '');
   return `<tr><td>${esc(e.date)}</td><td>${esc(e.staffName)}</td><td>${esc(e.reqTime)}</td><td>${esc(rText)}</td><td>${stat}</td><td>${act}</td></tr>`;
 }).join('') || '<tr><td colspan="6" class="mute">No EL requests found.</td></tr>';
 
 $('#elSubmitBtn').onclick = async () => {
   const sid = $('#elStaffSel').value, time = $('#elTime').value, reason = $('#elReasonForm').value;
   const remarks = reason==='Others'?$('#elOtherForm').value.trim():'';
   const m = t => $('#elMsg').textContent=t;
   if(!sid || !time || !reason) return m('Please fill all fields.');
   if(reason==='Others' && !remarks) return m('Please specify the reason.');
   const s = staff.find(x=>x.id===sid);
   if(!db) return m('Storage unavailable');
   
   $('#elSubmitBtn').disabled=true;
   try {
     await db.collection('el_requests').add({
       staffId: s.id, staffName: s.name, dept: s.dept||'', date: dstr(new Date()), reqTime: time, reason, remarks, status: 'PENDING', applied_at: Date.now()
     });
     m('EL Application submitted successfully (PENDING).');
     $('#elTime').value=''; $('#elOtherForm').value='';
   } catch(e) {
     m('Error: ' + e.message);
   }
   $('#elSubmitBtn').disabled=false;
 };
"""

# inject at end of render()
start_render = content.find("function render(){")
end_render = content.find("\n if(tab!=='att')return;", start_render)
content = content[:end_render] + render_injection + content[end_render:]


with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
