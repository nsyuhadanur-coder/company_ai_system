import re

with open('FaceClock.html', 'r', encoding='utf-8', errors='ignore') as f:
    content = f.read()

content = content.replace("m('Hold still. Capturing multiple angles');", "m('Hold still. Capturing multiple angles...');")

with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
