import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Remove form from p-clock
start_card = content.find('<div class="card" style="margin-bottom:20px; background: rgba(30,41,59,0.5);">')
if start_card != -1:
    end_card = content.find('<h2>Recent Scans</h2>', start_card)
    if end_card != -1:
        content = content[:start_card] + content[end_card:]

# 2. Re-create the EL Portal layout
el_section_full = """
<section id="p-el" hidden>
 <div class="split">
  <div>
   <h2>Apply for Early Leave (EL)</h2>
   <div class="card">
    <label style="display:block;margin-bottom:5px">Select Staff:</label>
    <select id="elStaffSel" class="txt" style="width:100%;margin-bottom:15px"></select>
    
    <label style="display:block;margin-bottom:5px">EL Reason:</label>
    <select id="elReasonForm" class="txt" style="width:100%;margin-bottom:15px">
     <option value="Family Matters">Family Matters</option>
     <option value="Medical Checkup">Medical Checkup</option>
     <option value="Others">Others</option>
    </select>
    
    <input type="text" id="elOtherForm" class="txt" placeholder="Please specify your reason..." hidden style="width:100%;margin-bottom:15px">
    
    <button class="btn" id="elSubmitBtn" style="width:100%">Submit EL</button>
    <p id="elMsg" class="mute" style="margin-top:10px"></p>
   </div>
  </div>
  <div style="flex:2">
   <h2>EL Records (History)</h2>
   <div class="card" style="padding:0;overflow-x:auto">
    <table class="tbl">
     <thead><tr><th>Date</th><th>Staff</th><th>Reason/Remarks</th><th>Status</th></tr></thead>
     <tbody id="elRows"></tbody>
    </table>
   </div>
  </div>
 </div>
</section>
"""

# Replace the existing p-el
start_el = content.find('<section id="p-el"')
if start_el != -1:
    end_el = content.find('</section>', start_el)
    content = content[:start_el] + el_section_full + content[end_el + 10:]

# 3. Ensure JS renders EL rows and selects
render_js = """
 if($('#elStaffSel')){
   $('#elStaffSel').innerHTML = '<option value="">-- Select Employee --</option>' + staff.map(s=>`<option value="${esc(s.id)}">${esc(s.name)}</option>`).join('');
   $('#elReasonForm').onchange=e=>$('#elOtherForm').hidden=(e.target.value!=='Others');
   
   $('#elSubmitBtn').onclick = async () => {
     const sid = $('#elStaffSel').value, reason = $('#elReasonForm').value;
     const remarks = reason==='Others'?$('#elOtherForm').value.trim():'';
     const m = t => $('#elMsg').textContent=t;
     if(!sid || !reason) return m('Please select staff and reason.');
     if(reason==='Others' && !remarks) return m('Please specify the reason.');
     const s = staff.find(x=>x.id===sid);
     if(!db) return m('Storage unavailable');
     
     $('#elSubmitBtn').disabled=true;
     try {
       await db.collection('el_requests').add({
         staffId: s.id, staffName: s.name, dept: s.dept||'', date: dstr(new Date()), reason, remarks, applied_at: Date.now()
       });
       m('EL applied successfully! You can now clock out.');
       $('#elOtherForm').value='';
     } catch(e) {
       m('Error: ' + e.message);
     }
     $('#elSubmitBtn').disabled=false;
   };
 }
 
 if($('#elRows')){
   $('#elRows').innerHTML = els.map(e => {
     let stat = '<span class="pill p-in">APPLIED</span>';
     let rText = e.reason + (e.remarks ? ` - ${e.remarks}` : '');
     return `<tr><td>${esc(e.date)}</td><td>${esc(e.staffName)}</td><td>${esc(rText)}</td><td>${stat}</td></tr>`;
   }).join('') || '<tr><td colspan="4" class="mute">No EL requests found.</td></tr>';
 }
 """

# Find where to inject it in render()
if "if($('#elStaffSel')){" not in content:
    start_inj = content.find("if(tab!=='att')return;")
    if start_inj != -1:
        content = content[:start_inj] + render_js + content[start_inj:]


with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
