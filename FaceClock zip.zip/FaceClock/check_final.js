
const $=s=>document.querySelector(s),pad=n=>String(n).padStart(2,'0'),sleep=ms=>new Promise(r=>setTimeout(r,ms));
const dstr=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`,tstr=t=>{const d=new Date(t);return pad(d.getHours())+':'+pad(d.getMinutes())};
const START=9*60,GRACE=15; // work starts 09:00, late after 09:15
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

/* Local storage instead of the cloud database: everything stays on this computer */
const subs={};
function col(n){
 const rd=()=>{try{return JSON.parse(localStorage.getItem('fc_'+n)||'{}')}catch(e){return{}}};
 const wr=o=>{localStorage.setItem('fc_'+n,JSON.stringify(o));(subs[n]||[]).forEach(f=>f())};
 const q={orderBy:()=>q,limit:()=>q,
  onSnapshot(cb){const f=()=>{const docs=Object.entries(rd()).map(([id,v])=>({id,data:()=>v}));if(n==='attendance')docs.sort((a,b)=>b.data().ts-a.data().ts);cb({docs})};(subs[n]=subs[n]||[]).push(f);f()},
  add(v){const o=rd();o[Date.now()+'_'+Math.random().toString(36).slice(2,7)]=v;wr(o);return Promise.resolve()},
  doc:id=>({set(v,opts){const o=rd();o[id]=opts&&opts.merge?{...(o[id]||{}),...v}:v;wr(o);return Promise.resolve()},update(v){const o=rd();if(o[id])o[id]={...o[id],...v};wr(o);return Promise.resolve()},delete(){const o=rd();delete o[id];wr(o);return Promise.resolve()}})};
 return q}
let mode='in',db=null,dl=null,staff=[],logs=[],els=[],tab='clock',ready=false,busy=false,last={id:null,n:0},cool={};
const OPT=()=>new faceapi.TinyFaceDetectorOptions({inputSize:320,scoreThreshold:.5});
let scanErr='';
async function scan(){try{const r=await faceapi.detectSingleFace($('#cam'),OPT()).withFaceLandmarks(true).withFaceDescriptor();scanErr='';return r||null}catch(e){scanErr=e&&e.message||String(e);return null}}
function say(t,c=''){const e=$('#st');e.textContent=t;e.className='status '+c}
function ring(c){$('#ring').className='ring '+c}
function tick(){const d=new Date();$('#clk').textContent=pad(d.getHours())+':'+pad(d.getMinutes())+':'+pad(d.getSeconds());$('#dt').textContent=d.toLocaleDateString(undefined,{weekday:'long',day:'numeric',month:'long',year:'numeric'})}
setInterval(tick,1000);tick();

$('#nav').onclick=e=>{const t=e.target.dataset.t;if(!t)return;tab=t;document.body.dataset.tab=t;
 document.querySelectorAll('nav button').forEach(b=>b.setAttribute('aria-current',b.dataset.t===t));
 ['clock','staff','att'].forEach(k=>$('#p-'+k).hidden=k!==t);ring('');render()};

const helps={auto:''};
function setMode(m){mode='auto';last={id:null,n:0}}
setMode('auto');
function match(d){let best=null,bd=9,bIdx=-1,bVec=null;for(const s of staff){if(s.vecs&&s.vecs.length){for(let i=0;i<s.vecs.length;i++){const x=faceapi.euclideanDistance(d,s.vecs[i]);if(x<bd){bd=x;best=s;bIdx=i;bVec=s.vecs[i];}}}else{const x=faceapi.euclideanDistance(d,s.vec);if(x<bd){bd=x;best=s;bIdx=-1;bVec=s.vec;}}}return bd<.5?{...best,dist:bd,currVec:d,matchIdx:bIdx,matchVec:bVec}:null}
async function handle(r){
 if(!r){last={id:null,n:0};ring('');say('Look at the camera to clock in or out.');return}
 const m=match(r.descriptor);
 if(!m){last={id:null,n:0};ring('unk');say(staff.length?'Face not recognised. Ask HR to enrol you.':'No staff enrolled yet. Open the Staff tab.','warn');return}
 last=last.id===m.id?{id:m.id,n:last.n+1}:{id:m.id,n:1};ring('seeing');
 if(last.n>=2)await clockIn(m)}
async function clockIn(m){
 if(!db){say('Storage unavailable in this browser.','bad');return}
 const now=Date.now(),d=new Date(now),today=dstr(d);
 const mine=logs.filter(l=>l.staffId===m.id&&l.date===today).sort((a,b)=>a.ts-b.ts),lg=mine[mine.length-1];
 let type;
 if(now-(cool[m.id]||0)<60000){ring('ok');say(`${m.name}: already clocked ${lg?lg.type:'in'} at ${lg?tstr(lg.ts):tstr(now)}. Scan again in a minute to clock out.`,'ok');return}
 type=!lg||lg.type==='out'?'in':'out';
 if(type==='in'&&d.getHours()<9){ring('unk');say(`${m.name}: Too early to clock in. Starts at 9:00 AM.`,'warn');return}
 const isLate=type==='in'&&(d.getHours()>9||(d.getHours()===9&&d.getMinutes()>0));
 let ot=0, el=false, elReason='';
 if(type==='out'){
  const otStart=new Date(d.getFullYear(),d.getMonth(),d.getDate(),18,0,0,0).getTime();
  ot=now>otStart?now-otStart:0;
  if(now<otStart){
   busy=true; 
   $('#elModal').style.display='flex'; 
   $('#elReason').value=''; $('#elOther').hidden=true; $('#elOther').value='';
   $('#elReason').onchange=e=>$('#elOther').hidden=(e.target.value!=='Others');
   let res = await new Promise(r=>{
    $('#elCancel').onclick=()=>{r(null)};
    $('#elConfirm').onclick=()=>{let v=$('#elReason').value; r(v==='Others'?$('#elOther').value.trim():v)};
   });
   $('#elModal').style.display='none';
   if(res===null){busy=false; last={id:null,n:0}; ring('unk'); say('Clock-out cancelled.','warn'); return;}
   el=true; elReason=res;
  }
 }
 busy=true;
 try{
  await db.collection('attendance').add({staffId:m.id,name:m.name,dept:m.dept||'',type,ts:now,date:today,late:isLate,ot,el,elReason});
  cool[m.id]=now;ring('ok');say(`${m.name}: CLOCKED ${type.toUpperCase()} at ${tstr(now)}${isLate?' (LATE)':''}`,type==='out'?'out':isLate?'warn':'ok');
  if(m.dist<0.35&&m.matchVec&&m.currVec){
   const updatedVec=Array.from(m.matchVec).map((val,i)=>val*0.9+m.currVec[i]*0.1);
   if(m.matchIdx>=0&&m.vecs){
    const newVecs=[...m.vecs];newVecs[m.matchIdx]=updatedVec;
    db.collection('staff').doc(m.id).update({vecs:newVecs}).catch(e=>{});
   }else{
    db.collection('staff').doc(m.id).update({vec:updatedVec}).catch(e=>{});
   }
  }
 }
 catch(e){say('Could not save attendance: '+(e.message||e.code),'bad')}
 setTimeout(()=>{busy=false;last={id:null,n:0}},2500)}
async function loop(){window.__loop=1;
 try{if(tab!=='att'&&ready&&!busy&&document.visibilityState==='visible'){const r=await scan();$('#dbg').textContent=scanErr?'Detector error: '+scanErr:r?'Face detected':'No face detected';if(tab==='clock')await handle(r);else ring(r?'seeing':'')}}catch(e){$('#dbg').textContent='Error: '+(e.message||e)}
 setTimeout(loop,450)}

async function enrol(){
 const name=$('#fName').value.trim(),id=$('#fId').value.trim(),dept=$('#fDept').value.trim(),m=t=>$('#enMsg').textContent=t;
 if(!name||!id)return m('Enter a name and a staff ID.');
 if(!/^[A-Za-z0-9_-]+$/.test(id))return m('Staff ID may only use letters, numbers, - and _.');
 if(!db)return m('Storage unavailable in this browser.');
 busy=true;$('#enrol').disabled=true;m('Hold still. Capturing multiple angles…');const ds=[];
 for(let i=0;i<20&&ds.length<5;i++){const r=await scan();if(r){
  const isUnique=!ds.some(existing=>faceapi.euclideanDistance(r.descriptor,existing)<0.1);
  if(isUnique)ds.push(r.descriptor);
 }await sleep(350)}
 if(ds.length<3){m('Face not clear or not enough angles. Move your head slightly and try again.')}
 else{
  const vecs=ds.map(d=>Array.from(d).map(v=>+v.toFixed(5)));
  const vec=vecs[0];
  try{await db.collection('staff').doc(id).set({name,dept,vec,vecs,at:Date.now()});m(`${name} enrolled with ${ds.length} profiles.`);['#fName','#fId','#fDept'].forEach(s=>$(s).value='')}
  catch(e){m('Could not save: '+(e.message||e.code))}}
 busy=false;$('#enrol').disabled=false}
$('#enrol').onclick=enrol;
$('#staffList').onclick=async e=>{const b=e.target.closest('button');if(!b)return;
 if(!b.dataset.arm){b.dataset.arm=1;b.textContent='Confirm remove';return}
 try{await db.collection('staff').doc(b.dataset.id).delete()}catch(x){}};

function summary(day){
 const map=new Map();staff.forEach(s=>map.set(s.id,{id:s.id,name:s.name,dept:s.dept,ev:[]}));
 logs.filter(l=>l.date===day).forEach(l=>{if(!map.has(l.staffId))map.set(l.staffId,{id:l.staffId,name:l.name,dept:l.dept,ev:[]});map.get(l.staffId).ev.push(l)});
 return [...map.values()].map(p=>{p.ev.sort((a,b)=>a.ts-b.ts);const ins=p.ev.filter(e=>e.type==='in'),lg=p.ev[p.ev.length-1];
  p.first=ins[0]?.ts;p.out=lg&&lg.type==='out'?lg.ts:null;p.hrs=p.first&&p.out?((p.out-p.first)/36e5).toFixed(1):'';
  const d=p.first&&new Date(p.first),mins=d?d.getHours()*60+d.getMinutes():0;
  p.absent=!p.first; p.late=p.first&&(ins[0]&&ins[0].late!==undefined?ins[0].late:mins>540);
  p.onsite=p.first&&!p.out;
  p.otHrs=lg&&lg.type==='out'&&lg.ot?(lg.ot/36e5).toFixed(1):'';
  p.elReason=lg&&lg.type==='out'&&lg.el?lg.elReason:'';
  
  if (p.absent) p.statusHTML = '<span class="pill p-bad">ABSENT</span>';
  else {
    p.statusHTML = p.late ? '<span class="pill p-warn">LATE</span>' : '<span class="pill p-ok">ON TIME</span>';
    if (p.out) {
      if (lg.el) {
        if (lg.elReason) p.statusHTML += ' <span class="pill p-warn" title="'+esc(lg.elReason)+'">EL ('+esc(lg.elReason)+')</span>';
        else p.statusHTML += ' <span class="pill p-bad">EARLY CLOCK-OUT</span>';
      } else {
        p.statusHTML += (lg.ot > 0) ? ' <span class="pill p-in">OVERTIME</span>' : ' <span class="pill p-ok">NORMAL CLOCK OUT</span>';
      }
    }
  }
  p.statusText = p.statusHTML.replace(/<[^>]+>/g, '').trim().replace(/\s{2,}/g, ', ');

  return p}).sort((a,b)=>a.name.localeCompare(b.name))}
function render(){
 $('#recent').innerHTML=logs.filter(l=>l.date===dstr(new Date())).slice(0,8).map(l=>`<li><span>${esc(l.name)}</span><span class="mute">Clock ${l.type} ${tstr(l.ts)}</span></li>`).join('')||'<li class="mute">No scans yet today.</li>';
 $('#staffList').innerHTML=staff.map(s=>`<li><span>${esc(s.name)} <span class="mute">${esc(s.id)} ${esc(s.dept)}</span></span><button class="btn ghost sm" data-id="${esc(s.id)}">Remove</button></li>`).join('')||'<li class="mute">Nobody enrolled yet.</li>';
 if(tab!=='att')return;
 const day=$('#day').value,rows=summary(day),cntA=rows.filter(r=>r.absent).length,cntL=rows.filter(r=>r.late).length;
 $('#sN').textContent=staff.length;$('#sP').textContent=rows.length-cntA;$('#sL').textContent=cntL;$('#sA').textContent=cntA;
 const drawChart=(p,l,a)=>{
  const c=$('#attChart');if(!c)return;const ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.clearRect(0,0,w,h);
  if(p+a===0){ctx.fillStyle='#eee';ctx.beginPath();ctx.arc(w/2,h/2,w/2-2,0,2*Math.PI);ctx.fill();$('#attLeg').innerHTML='<span style="color:#999">No data</span>';return;}
  const ontime=p-l,d=[{v:ontime,c:'#10b981',l:'On time'},{v:l,c:'#f59e0b',l:'Late'},{v:a,c:'#ef4444',l:'Absent'}];
  let tot=p+a,ang=-Math.PI/2,leg='';
  d.forEach(x=>{if(x.v===0)return;let pct=x.v/tot,end=ang+pct*2*Math.PI;
   ctx.fillStyle=x.c;ctx.beginPath();ctx.moveTo(w/2,h/2);ctx.arc(w/2,h/2,w/2-2,ang,end);ctx.fill();
   ang=end;leg+=`<div style="color:${x.c};font-weight:600">- ${x.l} <span style="color:#666;font-weight:400">(${Math.round(pct*100)}%)</span></div>`;});
  $('#attLeg').innerHTML=leg;
 };
 drawChart(rows.length-cntA, cntL, cntA);
 $('#rows').innerHTML=rows.map(r=>{ let dur=''; if(r.out&&r.el){let elD=Math.max(0,(new Date(new Date(r.out).setHours(18,0,0,0))-r.out)/36e5).toFixed(1); dur=`${elD} hrs EL`;}else if(r.otHrs) dur=`${r.otHrs} hrs OT`; return `<tr><td>${esc(r.id)}</td><td>${esc(r.name)}</td><td>${esc(r.dept)}</td><td>${r.first?tstr(r.first):'-'}</td><td>${r.out?tstr(r.out):r.onsite?'<span class="pill p-in">On site</span>':'-'}</td><td>${dur||'-'}</td><td>${esc(r.elReason||'')}</td><td>${r.statusHTML}</td></tr>`}).join('')||'<tr><td colspan="8" class="mute">Enrol staff to start tracking attendance.</td></tr>'}
$('#all').onclick=()=>{const q=v=>`"${String(v??'').replace(/"/g,'""')}"`;const csv=['Date,Time,Staff ID,Name,Department,Type,OT (ms)',...[...logs].sort((a,b)=>a.ts-b.ts).map(l=>[l.date,tstr(l.ts),l.staffId,l.name,l.dept,l.type,l.ot||''].map(q).join(','))].join('\n');dl.save({filename:'all-scans-'+dstr(new Date())+'.csv',data:csv})};
$('#day').value=dstr(new Date());$('#day').onchange=render;
$('#csv').onclick=async()=>{if(!dl)return;const day=$('#day').value,q=v=>`"${String(v??'').replace(/"/g,'""')}"`;
 const csv=['Staff ID,Name,Department,Date,Clock-in,Clock-out,Hours,OT Duration,Status',...summary(day).map(r=>[r.id,r.name,r.dept,day,r.first?tstr(r.first):'',r.out?tstr(r.out):'',r.hrs,r.otHrs,r.statusText].map(q).join(','))].join('\n');
 try{await dl.save({filename:`attendance-${day}.csv`,data:csv})}catch(e){}};

(async()=>{
 db={collection:col};dl={save:async({filename,data})=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+data],{type:'text/csv;charset=utf-8'}));a.download=filename;document.body.appendChild(a);a.click();a.remove()}};
 if(!dl)$('#csv').hidden=true;
 if(db){db.collection('staff').onSnapshot(s=>{staff=s.docs.map(d=>({id:d.id,...d.data()})).filter(x=>x.vec&&x.vec.length===128);render()},()=>{});
  db.collection('attendance').orderBy('ts','desc').limit(3000).onSnapshot(s=>{logs=s.docs.map(d=>d.data());render()},()=>{})}
 else say('Sign in to claude.ai to load and save attendance data.','warn');
 try{say('Loading face models…');await faceapi.tf.ready();const n=faceapi.nets;
  await Promise.all([n.tinyFaceDetector.loadFromUri('/m'),n.faceLandmark68TinyNet.loadFromUri('/m'),n.faceRecognitionNet.loadFromUri('/m')]);ready=true}
 catch(e){say('Could not load face models: '+e.message,'bad');return}
 if(!await startCam())return;
 loop()})();
async function startCam(){
 $('#retry').hidden=true;
 try{if(!navigator.mediaDevices?.getUserMedia)throw{name:'NoApi'};
  const s=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:640,height:480}});$('#cam').srcObject=s;await $('#cam').play();
  say('Look at the camera to clock in or out.');return true}
 catch(e){const n=e.name,why={NotAllowedError:'Camera access is blocked. Tap the camera or lock icon in the address bar, choose Allow, then press Try camera again. If the page is embedded here, open it in its own browser tab.',NotFoundError:'No camera found on this device. Connect a webcam and press Try camera again.',NotReadableError:'The camera is in use by another app or tab. Close it, then press Try camera again.',NoApi:'This browser cannot open the camera here. Open the link in its own tab in Chrome, Edge or Safari over https.'};
  say(why[n]||'Camera unavailable ('+(n||'error')+'). Open the page in its own browser tab and try again.','bad');$('#retry').hidden=false;return false}}
$('#retry').onclick=async()=>{if(await startCam()&&!window.__loop){window.__loop=1;loop()}};
