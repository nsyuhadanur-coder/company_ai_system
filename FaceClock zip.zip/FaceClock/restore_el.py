import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Add EL Portal tab back
if 'data-t="el"' not in content:
    content = content.replace(
        '<button data-t="att">Attendance</button>',
        '<button data-t="att">Attendance</button>\n  <button data-t="el">EL Portal</button>'
    )
    content = content.replace("['clock','staff','att'].forEach", "['clock','staff','att','el'].forEach")

# 2. Add EL Portal section back (just the records)
el_section = """
<section id="p-el" hidden>
 <div>
   <h2>EL Records (History)</h2>
   <div class="card" style="padding:0;overflow-x:auto">
    <table class="tbl">
     <thead><tr><th>Date</th><th>Staff</th><th>Reason/Remarks</th><th>Status</th></tr></thead>
     <tbody id="elRows"></tbody>
    </table>
   </div>
  </div>
</section>
"""

if '<section id="p-el"' not in content:
    content = content.replace("</main>", el_section + "</main>")


# 3. Add back the JS for elRows mapping
start_render = content.find("if($('#elStaffSel')){")
end_render = content.find("if(tab!=='att')return;", start_render)
if start_render != -1 and end_render != -1:
    new_render = """if($('#elStaffSel')){
   $('#elStaffSel').innerHTML = '<option value="">-- Select Employee --</option>' + staff.map(s=>`<option value="${esc(s.id)}">${esc(s.name)}</option>`).join('');
   $('#elReasonForm').onchange=e=>$('#elOtherForm').hidden=(e.target.value!=='Others');
   
   $('#elSubmitBtn').onclick = async () => {
     const sid = $('#elStaffSel').value, reason = $('#elReasonForm').value;
     const remarks = reason==='Others'?$('#elOtherForm').value.trim():'';
     const m = t => $('#elMsg').textContent=t;
     if(!sid || !reason) return m('Please select staff and reason.');
     if(reason==='Others' && !remarks) return m('Please specify the reason.');
     const s = staff.find(x=>x.id===sid);
     if(!db) return m('Storage unavailable');
     
     $('#elSubmitBtn').disabled=true;
     try {
       await db.collection('el_requests').add({
         staffId: s.id, staffName: s.name, dept: s.dept||'', date: dstr(new Date()), reason, remarks, applied_at: Date.now()
       });
       m('EL applied successfully! You can now clock out.');
       $('#elOtherForm').value='';
     } catch(e) {
       m('Error: ' + e.message);
     }
     $('#elSubmitBtn').disabled=false;
   };
 }
 
 if($('#elRows')){
   $('#elRows').innerHTML = els.map(e => {
     let stat = '<span class="pill p-in">APPLIED</span>';
     let rText = e.reason + (e.remarks ? ` - ${e.remarks}` : '');
     return `<tr><td>${esc(e.date)}</td><td>${esc(e.staffName)}</td><td>${esc(rText)}</td><td>${stat}</td></tr>`;
   }).join('') || '<tr><td colspan="4" class="mute">No EL requests found.</td></tr>';
 }
 
 """
    content = content[:start_render] + new_render + content[end_render:]

with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
