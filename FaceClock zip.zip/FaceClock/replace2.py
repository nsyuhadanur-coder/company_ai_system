import re

with open('FaceClock.html', 'r', encoding='utf-8') as f:
    content = f.read()

replacement = """function render(){
 $('#recent').innerHTML=logs.filter(l=>l.date===dstr(new Date())).slice(0,8).map(l=>`<li><span>${esc(l.name)}</span><span class="mute">Clock ${l.type} ${tstr(l.ts)}</span></li>`).join('')||'<li class="mute">No scans yet today.</li>';
 $('#staffList').innerHTML=staff.map(s=>`<li><span>${esc(s.name)} <span class="mute">${esc(s.id)} ${esc(s.dept)}</span></span><button class="btn ghost sm" data-id="${esc(s.id)}">Remove</button></li>`).join('')||'<li class="mute">Nobody enrolled yet.</li>';
 if(tab!=='att')return;
 const day=$('#day').value,rows=summary(day),cntA=rows.filter(r=>r.absent).length,cntL=rows.filter(r=>r.late).length;
 $('#sN').textContent=staff.length;$('#sP').textContent=rows.length-cntA;$('#sL').textContent=cntL;$('#sA').textContent=cntA;
 const drawChart=(p,l,a)=>{
  const c=$('#attChart');if(!c)return;const ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.clearRect(0,0,w,h);
  if(p+a===0){ctx.fillStyle='#eee';ctx.beginPath();ctx.arc(w/2,h/2,w/2-2,0,2*Math.PI);ctx.fill();$('#attLeg').innerHTML='<span style="color:#999">No data</span>';return;}
  const ontime=p-l,d=[{v:ontime,c:'#10b981',l:'On time'},{v:l,c:'#f59e0b',l:'Late'},{v:a,c:'#ef4444',l:'Absent'}];
  let tot=p+a,ang=-Math.PI/2,leg='';
  d.forEach(x=>{if(x.v===0)return;let pct=x.v/tot,end=ang+pct*2*Math.PI;
   ctx.fillStyle=x.c;ctx.beginPath();ctx.moveTo(w/2,h/2);ctx.arc(w/2,h/2,w/2-2,ang,end);ctx.fill();
   ang=end;leg+=`<div style="color:${x.c};font-weight:600">- ${x.l} <span style="color:#666;font-weight:400">(${Math.round(pct*100)}%)</span></div>`;});
  $('#attLeg').innerHTML=leg;
 };
 drawChart(rows.length-cntA, cntL, cntA);
 $('#rows').innerHTML=rows.map(r=>`<tr><td>${esc(r.id)}</td><td>${esc(r.name)}</td><td>${esc(r.dept)}</td><td>${r.first?tstr(r.first):'-'}</td><td>${r.out?tstr(r.out):r.onsite?'<span class="pill p-in">On site</span>':'-'}</td><td>${r.otHrs?r.otHrs+' hrs':'-'}</td><td>${r.statusHTML}</td></tr>`).join('')||'<tr><td colspan="7" class="mute">Enrol staff to start tracking attendance.</td></tr>'}"""

pattern = r"function render\(\)\{.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\}"
content = re.sub(pattern, replacement, content, count=1, flags=re.DOTALL)

with open('FaceClock.html', 'w', encoding='utf-8') as f:
    f.write(content)
